package v0alpha1

routes: {
	namespaced: {
		// This endpoint is an exact copy of the existing /history endpoint,
		// with the exception that error responses will be Kubernetes-style,
		// not Grafana-style. It will be replaced in the future with a better
		// more schema-friendly API.
		"/alertstate/history": {
			"GET": {
				name: "getAlertstatehistory"
				response: {
					body: [string]: _
				}
				responseMetadata: typeMeta: false
			}
		}

		// Query notification history.
		"/notification/query": {
			"POST": {
				name: "createNotificationquery"
				request: {
					body: #NotificationQuery
				}
				response: #NotificationQueryResult
				responseMetadata: typeMeta: false
			}
		}

		// Query alerts within notification history.
		"/notifications/queryalerts": {
			"POST": {
				name: "createNotificationsqueryalerts"
				request: {
					body: #AlertQuery
				}
				response: #AlertQueryResult
				responseMetadata: typeMeta: false
			}
		}
	}
}
